from .heatmap_digitizer import HeatmapDigitizer
from .heatmap_digitizer import main
